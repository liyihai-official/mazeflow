```
mazepy
├── LICENSE.md
├── README.md
├── __init__.py
├── frontier.py
├── generator.py
├── lib
│   └── __init__.py
└── search.py

2 directories, 7 files
```